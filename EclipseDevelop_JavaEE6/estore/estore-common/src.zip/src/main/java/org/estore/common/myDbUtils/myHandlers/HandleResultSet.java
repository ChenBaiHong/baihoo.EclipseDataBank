package org.estore.common.myDbUtils.myHandlers;

import java.sql.ResultSet;

public interface HandleResultSet {
	public Object handle(ResultSet resultSet);
}
