package com.baiHoo.http;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * ��location��302һ������ض���
 * @author Administrator
 *
 */
@WebServlet("/ServletDmo1")
public class ServletDmo1 extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// ��ҳ���������
		response.setContentType("text/html;charset=UTF-8");
		// response.getWriter().write("��೤��Ǯ...");
		// ��ûǮ
		response.setStatus(302);
		// �����Ҹ��೤�ĵ�ַ
		response.setHeader("location", "/webServlet03-http/1.html");
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
